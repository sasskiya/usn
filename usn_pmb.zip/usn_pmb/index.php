<?php
require_once 'database.php';
$stmt = $pdo->query("SELECT * FROM program_studi");
$prodi_list = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMB USN - Universitas Samudra Nusantara</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Mengatur latar belakang hero menggunakan foto gedung kampus dari folder img/kampus.jpg */
        .hero {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.7)), url('img/kampus.jpg') no-repeat center center/cover !important;
        }
        
        .section-tentang {
            background: linear-gradient(135deg, #0d1b2a, #1b263b) !important;
            color: #ffffff;
        }
        .section-tentang .section-title h2 {
            color: #d4af37 !important;
        }
        .section-tentang .section-title p, .section-tentang p {
            color: #e0e0e0 !important;
        }

        .section-info {
            background: #111827 !important;
            color: #ffffff;
        }
        .section-info .section-title h2 {
            color: #d4af37 !important;
        }
        .section-info .section-title p {
            color: #9ca3af !important;
        }
        .info-step-card {
            background: #1f2937 !important;
            border: 1px solid #374151;
            color: #fff;
        }
        .info-step-card p {
            color: #d1d5db !important;
        }
        
        .prodi-card {
            background: #ffffff;
            border-top: 4px solid #0077b6;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo-container">
            <span class="logo-badge">USN</span>
            <h1>Universitas Samudra Nusantara</h1>
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Beranda</a></li>
            <li><a href="#tentang">Tentang Kami</a></li>
            <li><a href="#prodi">Program Studi</a></li>
            <li><a href="#informasi">Informasi PMB</a></li>
            <li><a href="login.php" class="btn-login">Login</a></li>
        </ul>
    </nav>

    <!-- Hero Section -->
    <header class="hero">
        <div class="hero-content">
            <h2>SELAMAT DATANG DI USN</h2>
            <h3>Penerimaan Mahasiswa Baru Tahun Akademik 2027/2028</h3>
            <p>Bergabunglah bersama Universitas Samudra Nusantara untuk membangun masa depan gemilang melalui pendidikan tinggi berkualitas tinggi dan berdaya saing global.</p>
            <div class="hero-buttons">
                <a href="register.php" class="btn-primary">Daftar Sekarang</a>
                <a href="#prodi" class="btn-secondary">Lihat Program Studi</a>
            </div>
        </div>
    </header>

    <!-- Tentang Kami (Tema Gelap Elegan) -->
    <section id="tentang" class="section section-tentang">
        <div class="section-title">
            <h2>Tentang USN</h2>
            <p>Mengenal lebih dekat Universitas Samudra Nusantara</p>
        </div>
        <div style="max-width: 900px; margin: 0 auto; text-align: center;">
            <p style="font-size: 1.1rem; line-height: 1.8;">
                Universitas Samudra Nusantara (USN) adalah perguruan tinggi unggulan yang berkomitmen mencetak lulusan profesional, berintegritas, dan inovatif di bidang teknologi, hukum, dan kesehatan. Dengan fasilitas modern dan tenaga pengajar berpengalaman, USN siap membimbing Anda menuju kesuksesan karier masa depan.
            </p>
        </div>
    </section>

    <!-- Program Studi -->
    <section id="prodi" class="section" style="background: #f3f4f6;">
        <div class="section-title">
            <h2>Program Studi Pilihan</h2>
            <p>Pilih jalur mandiri dan tentukan masa depan Anda di salah satu program studi unggulan kami</p>
        </div>
        <div class="prodi-grid">
            <?php foreach ($prodi_list as $prodi): ?>
            <div class="prodi-card">
                <div class="card-body">
                    <h3 style="color: #0d1b2a;"><?= htmlspecialchars($prodi['nama_prodi']); ?></h3>
                    <p><?= htmlspecialchars($prodi['deskripsi']); ?></p>
                    <a href="register.php" class="btn-primary" style="display: inline-block; padding: 8px 15px; font-size: 0.9rem;">Pilih Program Studi</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Informasi PMB / Jalur Mandiri (Tema Gelap Kontras) -->
    <section id="informasi" class="section section-info">
        <div class="section-title">
            <h2>Informasi Jalur Mandiri</h2>
            <p>Tahapan pendaftaran mahasiswa baru USN 2027/2028</p>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; max-width: 1000px; margin: 0 auto;">
            <div class="info-step-card" style="padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);">
                <h3 style="color: #d4af37; margin-bottom: 10px;">1. Registrasi Akun</h3>
                <p>Buat akun calon mahasiswa baru menggunakan email dan nomor HP aktif Anda.</p>
            </div>
            <div class="info-step-card" style="padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);">
                <h3 style="color: #d4af37; margin-bottom: 10px;">2. Ujian Online</h3>
                <p>Kerjakan soal tes pilihan ganda sesuai dengan program studi pilihan Anda secara online.</p>
            </div>
            <div class="info-step-card" style="padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);">
                <h3 style="color: #d4af37; margin-bottom: 10px;">3. Daftar Ulang & NIM</h3>
                <p>Jika dinyatakan lulus, lakukan daftar ulang untuk mendapatkan Nomor Induk Mahasiswa (NIM).</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2027 Universitas Samudra Nusantara (USN). Hak Cipta Dilindungi.</p>
        <p style="font-size: 0.9rem; color: #adb5bd; margin-top: 5px;">Kontak: info@usn.ac.id | Telp: (021) 555-0199</p>
    </footer>

</body>
</html>