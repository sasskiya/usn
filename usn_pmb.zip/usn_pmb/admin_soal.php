<?php
session_start();
require_once 'database.php';

// Pengecekan sesi admin yang disesuaikan agar bisa multi-tab
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

// Tambah Soal
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah_soal'])) {
    $prodi_id = $_POST['prodi_id'];
    $pertanyaan = trim($_POST['pertanyaan']);
    $pilihan_a = trim($_POST['pilihan_a']);
    $pilihan_b = trim($_POST['pilihan_b']);
    $pilihan_c = trim($_POST['pilihan_c']);
    $pilihan_d = trim($_POST['pilihan_d']);
    $jawaban_benar = $_POST['jawaban_benar'];

    if (empty($pertanyaan) || empty($pilihan_a) || empty($pilihan_b) || empty($pilihan_c) || empty($pilihan_d)) {
        $error = "Semua kolom pertanyaan dan pilihan jawaban wajib diisi!";
    } else {
        $stmt = $pdo->prepare("INSERT INTO soal_tes (prodi_id, pertanyaan, pilihan_a, pilihan_b, pilihan_c, pilihan_d, jawaban_benar) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$prodi_id, $pertanyaan, $pilihan_a, $pilihan_b, $pilihan_c, $pilihan_d, $jawaban_benar]);
        $success = "Soal baru berhasil ditambahkan!";
        header("Refresh: 1; URL=admin_soal.php");
    }
}

// Edit Soal
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_soal'])) {
    $id = $_POST['id'];
    $prodi_id = $_POST['prodi_id'];
    $pertanyaan = trim($_POST['pertanyaan']);
    $pilihan_a = trim($_POST['pilihan_a']);
    $pilihan_b = trim($_POST['pilihan_b']);
    $pilihan_c = trim($_POST['pilihan_c']);
    $pilihan_d = trim($_POST['pilihan_d']);
    $jawaban_benar = $_POST['jawaban_benar'];

    if (empty($pertanyaan) || empty($pilihan_a) || empty($pilihan_b) || empty($pilihan_c) || empty($pilihan_d)) {
        $error = "Semua kolom pertanyaan dan pilihan jawaban wajib diisi!";
    } else {
        $stmt = $pdo->prepare("UPDATE soal_tes SET prodi_id = ?, pertanyaan = ?, pilihan_a = ?, pilihan_b = ?, pilihan_c = ?, pilihan_d = ?, jawaban_benar = ? WHERE id = ?");
        $stmt->execute([$prodi_id, $pertanyaan, $pilihan_a, $pilihan_b, $pilihan_c, $pilihan_d, $jawaban_benar, $id]);
        $success = "Soal berhasil diperbarui!";
        header("Refresh: 1; URL=admin_soal.php");
    }
}

// Hapus Soal
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $stmt = $pdo->prepare("DELETE FROM soal_tes WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_soal.php");
    exit;
}

// Ambil data soal yang akan diedit jika ada parameter edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $stmt_edit = $pdo->prepare("SELECT * FROM soal_tes WHERE id = ?");
    $stmt_edit->execute([$_GET['edit']]);
    $edit_data = $stmt_edit->fetch();
}

$soal_list = $pdo->query("SELECT s.*, ps.nama_prodi FROM soal_tes s JOIN program_studi ps ON s.prodi_id = ps.id ORDER BY s.id DESC")->fetchAll();
$prodi_list = $pdo->query("SELECT * FROM program_studi")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Soal Tes - Admin PMB USN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; background: #f4f6f9; }
        .sidebar { width: 260px; background: var(--primary-color); height: 100vh; position: fixed; padding: 20px 0; color: #fff; }
        .sidebar h2 { text-align: center; font-size: 1.2rem; margin-bottom: 30px; color: var(--gold-color); }
        .sidebar a { display: block; color: #adb5bd; padding: 12px 25px; text-decoration: none; font-weight: 500; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: var(--secondary-color); color: #fff; border-left: 4px solid var(--gold-color); }
        .main-content { margin-left: 260px; padding: 40px; width: calc(100% - 260px); }
        table { width: 100%; background: #fff; border-collapse: collapse; margin-top: 20px; border-radius: 6px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #dee2e6; font-size: 0.9rem; }
        th { background: var(--primary-color); color: #fff; }
        .form-card { background: #fff; padding: 25px; border-radius: 8px; margin-top: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ced4da; border-radius: 5px; font-size: 0.9rem; }
        .btn-secondary { background: #6c757d; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin PMB USN</h2>
        <a href="dashboard_admin.php">Dashboard</a>
        <a href="admin_calon_mahasiswa.php">Data Calon Mahasiswa</a>
        <a href="admin_soal.php" class="active">Data Soal Tes</a>
        <a href="admin_kelulusan.php">Peserta Lulus & Tidak Lulus</a>
        <a href="admin_daftar_ulang.php">Daftar Ulang & NIM</a>
        <a href="logout.php" style="color: #ff6b6b; margin-top: 30px;">Logout</a>
    </div>

    <div class="main-content">
        <h2>Kelola Soal Ujian Online</h2>

        <?php if ($error): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-top: 15px;"><?= $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div style="background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-top: 15px;"><?= $success; ?></div>
        <?php endif; ?>

        <!-- Form Tambah / Edit Soal -->
        <div class="form-card">
            <h3><?= $edit_data ? 'Edit Soal Ujian' : 'Tambah Soal Baru'; ?></h3>
            <form action="" method="POST" style="margin-top: 15px; display: grid; gap: 15px;">
                <?php if ($edit_data): ?>
                    <input type="hidden" name="edit_soal" value="1">
                    <input type="hidden" name="id" value="<?= $edit_data['id']; ?>">
                <?php else: ?>
                    <input type="hidden" name="tambah_soal" value="1">
                <?php endif; ?>

                <div class="form-group" style="margin: 0;">
                    <label>Program Studi</label>
                    <select name="prodi_id" required>
                        <?php foreach($prodi_list as $p): ?>
                            <option value="<?= $p['id']; ?>" <?= ($edit_data && $edit_data['prodi_id'] == $p['id']) ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($p['nama_prodi']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Pertanyaan</label>
                    <textarea name="pertanyaan" rows="3" required><?= $edit_data ? htmlspecialchars($edit_data['pertanyaan']) : ''; ?></textarea>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group" style="margin: 0;">
                        <label>Pilihan A</label>
                        <input type="text" name="pilihan_a" value="<?= $edit_data ? htmlspecialchars($edit_data['pilihan_a']) : ''; ?>" required>
                    </div>
                    <div class="form-group" style="margin: 0;">
                        <label>Pilihan B</label>
                        <input type="text" name="pilihan_b" value="<?= $edit_data ? htmlspecialchars($edit_data['pilihan_b']) : ''; ?>" required>
                    </div>
                    <div class="form-group" style="margin: 0;">
                        <label>Pilihan C</label>
                        <input type="text" name="pilihan_c" value="<?= $edit_data ? htmlspecialchars($edit_data['pilihan_c']) : ''; ?>" required>
                    </div>
                    <div class="form-group" style="margin: 0;">
                        <label>Pilihan D</label>
                        <input type="text" name="pilihan_d" value="<?= $edit_data ? htmlspecialchars($edit_data['pilihan_d']) : ''; ?>" required>
                    </div>
                </div>

                <div class="form-group" style="margin: 0;">
                    <label>Kunci Jawaban Benar</label>
                    <select name="jawaban_benar" required>
                        <option value="A" <?= ($edit_data && $edit_data['jawaban_benar'] == 'A') ? 'selected' : ''; ?>>A</option>
                        <option value="B" <?= ($edit_data && $edit_data['jawaban_benar'] == 'B') ? 'selected' : ''; ?>>B</option>
                        <option value="C" <?= ($edit_data && $edit_data['jawaban_benar'] == 'C') ? 'selected' : ''; ?>>C</option>
                        <option value="D" <?= ($edit_data && $edit_data['jawaban_benar'] == 'D') ? 'selected' : ''; ?>>D</option>
                    </select>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn-primary" style="padding: 10px 20px;"><?= $edit_data ? 'Update Soal' : 'Simpan Soal'; ?></button>
                    <?php if ($edit_data): ?>
                        <a href="admin_soal.php" class="btn-secondary" style="padding: 10px 20px; text-align: center;">Batal Edit</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Prodi</th>
                    <th>Pertanyaan</th>
                    <th>Kunci</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($soal_list)): ?>
                    <tr>
                        <td colspan="4" style="text-align: center; color: #777;">Belum ada data soal ujian.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($soal_list as $s): ?>
                    <tr>
                        <td><?= htmlspecialchars($s['nama_prodi']); ?></td>
                        <td><?= htmlspecialchars($s['pertanyaan']); ?></td>
                        <td><b><?= htmlspecialchars($s['jawaban_benar']); ?></b></td>
                        <td>
                            <a href="admin_soal.php?edit=<?= $s['id']; ?>" style="color: #007bff; text-decoration: none; font-weight: bold; margin-right: 10px;">Edit</a>
                            <a href="admin_soal.php?hapus=<?= $s['id']; ?>" onclick="return confirm('Hapus soal ini?')" style="color: #dc3545; text-decoration: none; font-weight: bold;">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>