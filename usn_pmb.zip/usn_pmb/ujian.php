<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data pendaftaran
$stmt = $pdo->prepare("SELECT * FROM calon_mahasiswa WHERE user_id = ?");
$stmt->execute([$user_id]);
$mhs = $stmt->fetch();

if (!$mhs) {
    header("Location: pendaftaran.php");
    exit;
}

// Cek apakah sudah pernah ujian
if ($mhs['status_pendaftaran'] == 'Selesai Ujian') {
    header("Location: hasil_tes.php");
    exit;
}

$prodi_id = $mhs['prodi_id'];

// Ambil 5 soal sesuai program studi
$stmt_soal = $pdo->prepare("SELECT * FROM soal_tes WHERE prodi_id = ?");
$stmt_soal->execute([$prodi_id]);
$soal_list = $stmt_soal->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $jawaban_user = $_POST['jawaban'] ?? [];
    $benar = 0;
    $total_soal = count($soal_list);

    foreach ($soal_list as $soal) {
        $soal_id = $soal['id'];
        $jwb_peserta = $jawaban_user[$soal_id] ?? '';
        if ($jwb_peserta === $soal['jawaban_benar']) {
            $benar++;
        }
    }

    // Hitung nilai (20 poin per soal benar, total maksimal 100)
    $nilai = $benar * 20;

    // Ambil batas kelulusan dari pengaturan sistem
    $stmt_setting = $pdo->query("SELECT nilai_pengaturan FROM pengaturan WHERE nama_pengaturan = 'batas_kelulusan'");
    $setting = $stmt_setting->fetch();
    $batas_kelulusan = $setting ? (int)$setting['nilai_pengaturan'] : 60;

    $status_kelulusan = ($nilai >= $batas_kelulusan) ? 'Lulus' : 'Tidak Lulus';

    // Simpan hasil tes
    $stmt_hasil = $pdo->prepare("INSERT INTO hasil_tes (calon_mahasiswa_id, nilai, status_kelulusan) VALUES (?, ?, ?)");
    $stmt_hasil->execute([$mhs['id'], $nilai, $status_kelulusan]);

    // Update status pendaftaran menjadi Selesai Ujian
    $stmt_update = $pdo->prepare("UPDATE calon_mahasiswa SET status_pendaftaran = 'Selesai Ujian' WHERE id = ?");
    $stmt_update->execute([$mhs['id']]);

    header("Location: hasil_tes.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ujian Online - PMB USN</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div style="max-width: 800px; margin: 40px auto; padding: 20px;">
        <h2>Ujian Online Jalur Mandiri</h2>
        <p style="color: #666; margin-bottom: 20px;">Nomor Tes: <b><?= htmlspecialchars($mhs['nomor_tes']); ?></b> | Jawablah 5 soal di bawah ini dengan teliti.</p>

        <form action="" method="POST">
            <?php $no = 1; foreach ($soal_list as $soal): ?>
                <div style="background: #fff; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
                    <p style="font-weight: bold; margin-bottom: 12px;"><?= $no++; ?>. <?= htmlspecialchars($soal['pertanyaan']); ?></p>
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <label><input type="radio" name="jawaban[<?= $soal['id']; ?>]" value="A" required> A. <?= htmlspecialchars($soal['pilihan_a']); ?></label>
                        <label><input type="radio" name="jawaban[<?= $soal['id']; ?>]" value="B"> B. <?= htmlspecialchars($soal['pilihan_b']); ?></label>
                        <label><input type="radio" name="jawaban[<?= $soal['id']; ?>]" value="C"> C. <?= htmlspecialchars($soal['pilihan_c']); ?></label>
                        <label><input type="radio" name="jawaban[<?= $soal['id']; ?>]" value="D"> D. <?= htmlspecialchars($soal['pilihan_d']); ?></label>
                    </div>
                </div>
            <?php endforeach; ?>
            <button type="submit" class="btn-primary" style="width: 100%; padding: 15px; font-size: 1rem; cursor: pointer;">Kirim Jawaban Ujian</button>
        </form>
    </div>
</body>
</html>