<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$list = $pdo->query("SELECT ht.*, cm.nomor_tes, u.nama_lengkap, ps.nama_prodi FROM hasil_tes ht JOIN calon_mahasiswa cm ON ht.calon_mahasiswa_id = cm.id JOIN users u ON cm.user_id = u.id JOIN program_studi ps ON cm.prodi_id = ps.id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelulusan Peserta - Admin PMB USN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; background: #f4f6f9; }
        .sidebar { width: 260px; background: var(--primary-color); height: 100vh; position: fixed; padding: 20px 0; color: #fff; }
        .sidebar h2 { text-align: center; font-size: 1.2rem; margin-bottom: 30px; color: var(--gold-color); }
        .sidebar a { display: block; color: #adb5bd; padding: 12px 25px; text-decoration: none; font-weight: 500; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: var(--secondary-color); color: #fff; border-left: 4px solid var(--gold-color); }
        .main-content { margin-left: 260px; padding: 40px; width: calc(100% - 260px); }
        table { width: 100%; background: #fff; border-collapse: collapse; margin-top: 20px; border-radius: 6px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #dee2e6; font-size: 0.9rem; }
        th { background: var(--primary-color); color: #fff; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin PMB USN</h2>
        <a href="dashboard_admin.php">Dashboard</a>
        <a href="admin_calon_mahasiswa.php">Data Calon Mahasiswa</a>
        <a href="admin_soal.php">Data Soal Tes</a>
        <a href="admin_kelulusan.php" class="active">Peserta Lulus & Tidak Lulus</a>
        <a href="admin_daftar_ulang.php">Daftar Ulang & NIM</a>
        <a href="logout.php" style="color: #ff6b6b; margin-top: 30px;">Logout</a>
    </div>

    <div class="main-content">
        <h2>Daftar Nilai & Kelulusan Peserta</h2>

        <table>
            <thead>
                <tr>
                    <th>No Tes</th>
                    <th>Nama Lengkap</th>
                    <th>Prodi</th>
                    <th>Nilai</th>
                    <th>Status Kelulusan</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($list as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['nomor_tes']); ?></td>
                    <td><?= htmlspecialchars($item['nama_lengkap']); ?></td>
                    <td><?= htmlspecialchars($item['nama_prodi']); ?></td>
                    <td><b><?= $item['nilai']; ?></b></td>
                    <td>
                        <?php if ($item['status_kelulusan'] == 'Lulus'): ?>
                            <span style="color: #28a745; font-weight: bold;">Lulus</span>
                        <?php else: ?>
                            <span style="color: #dc3545; font-weight: bold;">Tidak Lulus</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>