<?php
// Mulai sesi dengan penanganan aman
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'database.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "Email dan password wajib diisi!";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Regenerasi ID session untuk keamanan, tapi kita pisahkan data session 
            // berdasarkan role atau buat key khusus agar admin & user bisa berdampingan
            
            if ($user['role'] === 'admin') {
                // Set sesi khusus admin
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_nama'] = $user['nama_lengkap'];
                $_SESSION['role'] = 'admin';
                
                header("Location: dashboard_admin.php");
            } else {
                // Set sesi khusus user/pendaftar
                $_SESSION['user_logged_in'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
                $_SESSION['role'] = 'user';
                
                header("Location: dashboard_user.php");
            }
            exit;
        } else {
            $error = "Email atau password salah!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PMB USN</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <h2>Login PMB USN</h2>
            <?php if ($error): ?>
                <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9rem;"><?= $error; ?></div>
            <?php endif; ?>
            
            <form action="" method="POST">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn-block">Login</button>
            </form>
            <div class="auth-links">
                <p>Belum punya akun? <a href="register.php">Daftar</a> | <a href="index.php">Beranda</a></p>
            </div>
        </div>
    </div>
</body>
</html>