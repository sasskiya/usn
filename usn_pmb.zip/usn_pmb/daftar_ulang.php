<?php
session_start();
require_once 'database.php';

// Menyesuaikan dengan sesi multi-tab user
if (!isset($_SESSION['user_logged_in']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Ambil data pendaftaran & hasil tes
$stmt = $pdo->prepare("SELECT cm.*, ps.nama_prodi, ht.status_kelulusan FROM calon_mahasiswa cm JOIN program_studi ps ON cm.prodi_id = ps.id JOIN hasil_tes ht ON cm.id = ht.calon_mahasiswa_id WHERE cm.user_id = ?");
$stmt->execute([$user_id]);
$data = $stmt->fetch();

if (!$data || $data['status_kelulusan'] != 'Lulus') {
    header("Location: dashboard_user.php");
    exit;
}

// Cek apakah data daftar ulang sudah ada
$stmt_du = $pdo->prepare("SELECT * FROM daftar_ulang WHERE calon_mahasiswa_id = ?");
$stmt_du->execute([$data['id']]);
$daftar_ulang = $stmt_du->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $no_wali = trim($_POST['no_wali']);
    $alamat_wali = trim($_POST['alamat_wali']);
    $ukuran_almamater = $_POST['ukuran_almamater'];
    $nomor_kip_kks = trim($_POST['nomor_kip_kks']);

    if (empty($no_wali) || empty($alamat_wali) || empty($ukuran_almamater)) {
        $error = "Nomor HP Wali, Alamat Wali, dan Ukuran Almamater wajib diisi!";
    } else {
        if (!$daftar_ulang) {
            // Generate NIM unik (contoh: USN27-001)
            $stmt_count = $pdo->query("SELECT COUNT(*) as total FROM daftar_ulang WHERE status_daftar_ulang = 'Selesai'");
            $row = $stmt_count->fetch();
            $next_nim_num = $row['total'] + 1;
            $nim = "USN27-" . str_pad($next_nim_num, 3, '0', STR_PAD_LEFT);

            // Insert data daftar ulang lengkap
            $stmt_insert = $pdo->prepare("INSERT INTO daftar_ulang (calon_mahasiswa_id, status_daftar_ulang, tanggal_daftar_ulang, nim, no_wali, alamat_wali, ukuran_almamater, nomor_kip_kks) VALUES (?, 'Selesai', NOW(), ?, ?, ?, ?, ?)");
            $stmt_insert->execute([$data['id'], $nim, $no_wali, $alamat_wali, $ukuran_almamater, $nomor_kip_kks]);
            $success = "Daftar ulang berhasil diselesaikan!";
        } else {
            // Update data jika sudah pernah isi
            $stmt_update = $pdo->prepare("UPDATE daftar_ulang SET no_wali = ?, alamat_wali = ?, ukuran_almamater = ?, nomor_kip_kks = ? WHERE calon_mahasiswa_id = ?");
            $stmt_update->execute([$no_wali, $alamat_wali, $ukuran_almamater, $nomor_kip_kks, $data['id']]);
            $success = "Data daftar ulang berhasil diperbarui!";
        }
        
        // Refresh data setelah submit
        $stmt_du->execute([$data['id']]);
        $daftar_ulang = $stmt_du->fetch();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Ulang & NIM - PMB USN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .container {
            width: 100%;
            max-width: 750px;
            margin: 100px auto 40px auto;
            padding: 0 15px;
            box-sizing: border-box;
        }
        .card {
            background: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(13, 27, 42, 0.08);
            border-top: 5px solid #d4af37;
        }
        .card h2 {
            color: #0d1b2a;
            font-size: 1.5rem;
            margin-bottom: 8px;
        }
        .info-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 15px 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .info-box p {
            margin-bottom: 8px;
            font-size: 0.95rem;
            color: #475569;
        }
        .info-box p strong {
            color: #0d1b2a;
        }
        
        /* Grid Form Responsif */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        @media (max-width: 600px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            font-size: 0.9rem;
            color: #0d1b2a;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 0.9rem;
            box-sizing: border-box;
        }
        .btn-submit {
            display: block;
            width: 100%;
            padding: 14px;
            background: #10b981;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2);
        }
        .btn-submit:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        .success-box {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            color: #166534;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            margin-top: 25px;
        }
        .nim-display {
            font-size: 1.8rem;
            font-weight: 700;
            letter-spacing: 1px;
            color: #0d1b2a;
            margin: 15px 0;
            background: #ffffff;
            padding: 10px;
            border-radius: 6px;
            border: 1px dashed #86efac;
            display: inline-block;
            word-break: break-all;
        }
    </style>
</head>
<body>

    <!-- Navbar Responsif -->
    <nav class="navbar" style="background: #0d1b2a; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <div class="logo-container">
            <span class="logo-badge" style="background: #d4af37; color: #0d1b2a; padding: 6px 10px; border-radius: 6px; font-weight: bold;">USN</span>
            <h1 style="font-size: 1.1rem; color: #fff;">PMB USN — Daftar Ulang</h1>
        </div>
        <ul class="nav-links">
            <li><a href="dashboard_user.php">Dashboard</a></li>
            <li><a href="logout.php" style="color: #f87171; font-weight: 600;">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <h2>Formulir Daftar Ulang Mahasiswa Baru</h2>
            <p style="color: #64748b; margin-bottom: 20px; font-size: 0.95rem;">Lengkapi data tambahan di bawah ini untuk meresmikan status mahasiswa dan menerbitkan NIM.</p>

            <?php if ($error): ?>
                <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9rem;"><?= $error; ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div style="background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9rem;"><?= $success; ?></div>
            <?php endif; ?>

            <div class="info-box">
                <p><strong>Nomor Tes:</strong> <?= htmlspecialchars($data['nomor_tes']); ?></p>
                <p><strong>Nama Lengkap:</strong> <?= htmlspecialchars($_SESSION['nama_lengkap']); ?></p>
                <p><strong>Program Studi:</strong> <?= htmlspecialchars($data['nama_prodi']); ?></p>
                <p><strong>Status Kelulusan:</strong> <span style="color: #166534; font-weight: bold;">Lulus</span></p>
            </div>

            <form action="" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Nomor HP Orang Tua / Wali</label>
                        <input type="text" name="no_wali" value="<?= htmlspecialchars($daftar_ulang['no_wali'] ?? ''); ?>" placeholder="Contoh: 081234567890" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Ukuran Jas Almamater</label>
                        <select name="ukuran_almamater" required>
                            <option value="">-- Pilih Ukuran --</option>
                            <option value="S" <?= (isset($daftar_ulang['ukuran_almamater']) && $daftar_ulang['ukuran_almamater'] == 'S') ? 'selected' : ''; ?>>S</option>
                            <option value="M" <?= (isset($daftar_ulang['ukuran_almamater']) && $daftar_ulang['ukuran_almamater'] == 'M') ? 'selected' : ''; ?>>M</option>
                            <option value="L" <?= (isset($daftar_ulang['ukuran_almamater']) && $daftar_ulang['ukuran_almamater'] == 'L') ? 'selected' : ''; ?>>L</option>
                            <option value="XL" <?= (isset($daftar_ulang['ukuran_almamater']) && $daftar_ulang['ukuran_almamater'] == 'XL') ? 'selected' : ''; ?>>XL</option>
                            <option value="XXL" <?= (isset($daftar_ulang['ukuran_almamater']) && $daftar_ulang['ukuran_almamater'] == 'XXL') ? 'selected' : ''; ?>>XXL</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Alamat Orang Tua / Wali</label>
                    <textarea name="alamat_wali" rows="3" placeholder="Masukkan alamat lengkap orang tua/wali..." required><?= htmlspecialchars($daftar_ulang['alamat_wali'] ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label>Nomor KIP-Kuliah / KKS (Opsional)</label>
                    <input type="text" name="nomor_kip_kks" value="<?= htmlspecialchars($daftar_ulang['nomor_kip_kks'] ?? ''); ?>" placeholder="Kosongkan jika tidak ada">
                </div>

                <div style="margin-top: 20px;">
                    <?php if (!$daftar_ulang || $daftar_ulang['status_daftar_ulang'] == 'Belum Daftar Ulang'): ?>
                        <button type="submit" class="btn-submit">Konfirmasi & Terbitkan NIM</button>
                    <?php else: ?>
                        <button type="submit" class="btn-submit" style="background: #0077b6;">Perbarui Data Daftar Ulang</button>
                    <?php endif; ?>
                </div>
            </form>

            <?php if ($daftar_ulang && $daftar_ulang['status_daftar_ulang'] == 'Selesai'): ?>
                <div class="success-box">
                    <h3 style="font-size: 1.2rem; margin-bottom: 5px;">🎉 Daftar Ulang Selesai!</h3>
                    <p style="margin: 5px 0 10px 0; color: #15803d;">Nomor Induk Mahasiswa (NIM) resmi Anda:</p>
                    <div class="nim-display"><?= htmlspecialchars($daftar_ulang['nim']); ?></div>
                    <p style="font-size: 0.85rem; color: #166534; margin-top: 5px;">Simpan NIM ini untuk keperluan akademik selanjutnya.</p>
                </div>
            <?php endif; ?>

            <div style="margin-top: 25px; text-align: center;">
                <a href="dashboard_user.php" style="color: #0077b6; text-decoration: none; font-weight: 600;">← Kembali ke Dashboard</a>
            </div>
        </div>
    </div>

</body>
</html>