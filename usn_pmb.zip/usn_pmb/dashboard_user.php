<?php
session_start();
require_once 'database.php';

// Menyesuaikan dengan sesi multi-tab user
if (!isset($_SESSION['user_logged_in']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$nama_lengkap = $_SESSION['nama_lengkap'];

// Ambil data pendaftaran calon mahasiswa
$stmt = $pdo->prepare("SELECT cm.*, ps.nama_prodi FROM calon_mahasiswa cm JOIN program_studi ps ON cm.prodi_id = ps.id WHERE cm.user_id = ?");
$stmt->execute([$user_id]);
$pendaftaran = $stmt->fetch();

$hasil_tes = null;
$daftar_ulang = null;

if ($pendaftaran) {
    // Ambil hasil tes
    $stmt_hasil = $pdo->prepare("SELECT * FROM hasil_tes WHERE calon_mahasiswa_id = ?");
    $stmt_hasil->execute([$pendaftaran['id']]);
    $hasil_tes = $stmt_hasil->fetch();

    // Ambil data daftar ulang
    $stmt_du = $pdo->prepare("SELECT * FROM daftar_ulang WHERE calon_mahasiswa_id = ?");
    $stmt_du->execute([$pendaftaran['id']]);
    $daftar_ulang = $stmt_du->fetch();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User - PMB USN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Mengatur background halaman menggunakan foto gedung kampus dengan lapisan transparan gelap */
        body {
            background: linear-gradient(rgba(13, 27, 42, 0.85), rgba(13, 27, 42, 0.90)), url('img/kampus.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .dashboard-container { 
            max-width: 1100px; 
            margin: 100px auto 40px auto; 
            padding: 0 20px; 
            box-sizing: border-box;
        }
        .welcome-banner {
            background: rgba(27, 38, 59, 0.9);
            backdrop-filter: blur(10px);
            color: #fff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            margin-bottom: 30px;
            border-left: 6px solid #d4af37;
        }
        .welcome-banner h2 {
            font-size: 1.8rem;
            margin-bottom: 8px;
            color: #fff;
        }
        .welcome-banner p {
            color: #cbd5e1;
            font-size: 1rem;
        }
        .card-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); 
            gap: 20px; 
            margin-bottom: 30px; 
        }
        .info-card { 
            background: rgba(255, 255, 255, 0.95); 
            backdrop-filter: blur(10px);
            padding: 25px; 
            border-radius: 12px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.2); 
            border-top: 4px solid #0077b6;
            transition: transform 0.2s ease;
        }
        .info-card:hover {
            transform: translateY(-3px);
        }
        .info-card h3 { 
            color: #64748b; 
            margin-bottom: 8px; 
            font-size: 0.95rem; 
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .info-card p {
            font-size: 1.25rem;
            font-weight: 700;
            color: #0d1b2a;
        }
        .action-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .badge-status { 
            display: inline-block; 
            padding: 6px 14px; 
            border-radius: 20px; 
            font-weight: 600; 
            font-size: 0.85rem; 
        }
        .bg-menunggu { background: #fef3c7; color: #b45309; }
        .bg-lulus { background: #dcfce7; color: #166534; }
        .bg-tidak-lulus { background: #fee2e2; color: #991b1b; }
        
        .btn-action {
            display: inline-block;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }
        .btn-action:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

    <!-- Navbar Bersih & Modern -->
    <nav class="navbar" style="background: rgba(13, 27, 42, 0.95); backdrop-filter: blur(10px); box-shadow: 0 2px 10px rgba(0,0,0,0.3);">
        <div class="logo-container">
            <span class="logo-badge" style="background: #d4af37; color: #0d1b2a; padding: 6px 10px; border-radius: 6px; font-weight: bold;">USN</span>
            <h1 style="font-size: 1.1rem; color: #fff;">PMB USN — Dashboard</h1>
        </div>
        <ul class="nav-links">
            <li><a href="dashboard_user.php" style="color: #d4af37;">Dashboard</a></li>
            <li><a href="logout.php" style="color: #f87171; font-weight: 600;">Logout</a></li>
        </ul>
    </nav>

    <div class="dashboard-container">
        
        <!-- Banner Selamat Datang -->
        <div class="welcome-banner">
            <h2>Selamat Datang, <?= htmlspecialchars($nama_lengkap); ?>!</h2>
            <p>Kelola pendaftaran Jalur Mandiri, ikuti ujian online, dan pantau status kelulusan Anda melalui panel modern ini.</p>
        </div>

        <?php if (!$pendaftaran): ?>
            <!-- Belum Daftar -->
            <div class="action-card" style="text-align: center; padding: 50px 20px;">
                <h3 style="color: #0d1b2a; font-size: 1.4rem; margin-bottom: 10px;">Anda Belum Mengisi Formulir Pendaftaran</h3>
                <p style="color: #64748b; margin-bottom: 25px; max-width: 500px; margin-left: auto; margin-right: auto;">Silakan lengkapi data diri Anda dan tentukan program studi pilihan untuk melanjutkan ke tahap seleksi.</p>
                <a href="pendaftaran.php" class="btn-action" style="background: #d4af37; color: #0d1b2a;">Isi Formulir Pendaftaran Sekarang</a>
            </div>
        <?php else: ?>
            <!-- Kartu Ringkasan Informasi -->
            <div class="card-grid">
                <div class="info-card">
                    <h3>Nomor Tes</h3>
                    <p style="color: #0077b6;"><?= htmlspecialchars($pendaftaran['nomor_tes']); ?></p>
                </div>
                <div class="info-card" style="border-top-color: #d4af37;">
                    <h3>Program Studi Pilihan</h3>
                    <p><?= htmlspecialchars($pendaftaran['nama_prodi']); ?></p>
                </div>
                <div class="info-card" style="border-top-color: #10b981;">
                    <h3>Status Ujian</h3>
                    <p style="margin-top: 6px;"><span class="badge-status bg-menunggu"><?= htmlspecialchars($pendaftaran['status_pendaftaran']); ?></span></p>
                </div>
            </div>

            <!-- Panel Aksi Utama -->
            <div class="action-card">
                <h3 style="margin-bottom: 15px; color: #0d1b2a; font-size: 1.2rem; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px;">Tahapan Seleksi & Kelulusan</h3>
                
                <?php if ($pendaftaran['status_pendaftaran'] == 'Menunggu Ujian'): ?>
                    <p style="color: #475569; margin-bottom: 20px;">Persyaratan pendaftaran Anda telah lengkap. Silakan mulai ujian online sesuai dengan kelompok soal program studi yang dipilih.</p>
                    <a href="ujian.php" class="btn-action" style="background: #0077b6; color: #fff;">Mulai Ujian Online Sekarang</a>
                <?php else: ?>
                    <p style="color: #475569; margin-bottom: 20px;">Ujian online telah selesai dikerjakan dan jawaban Anda sudah terekam di sistem.</p>
                    <!-- Perubahan di sini: kata 'Nilai' dihapus total -->
                    <a href="hasil_tes.php" class="btn-action" style="background: #0f172a; color: #fff;">Lihat Hasil Seleksi</a>
                <?php endif; ?>

                <?php if ($hasil_tes && $hasil_tes['status_kelulusan'] == 'Lulus'): ?>
                    <hr style="margin: 25px 0; border: 0; border-top: 1px solid #e2e8f0;">
                    <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                        <h3 style="margin-bottom: 5px; color: #166534; font-size: 1.1rem;">🎉 Selamat, Anda Dinyatakan LULUS!</h3>
                        <p style="color: #15803d; font-size: 0.95rem;">Silakan lanjutkan proses daftar ulang untuk mendapatkan Nomor Induk Mahasiswa (NIM) resmi.</p>
                    </div>
                    <a href="daftar_ulang.php" class="btn-action" style="background: #10b981; color: #fff;">Menu Daftar Ulang & NIM</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>