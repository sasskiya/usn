<?php
session_start();
require_once 'database.php';

// Menyesuaikan dengan sesi multi-tab user
if (!isset($_SESSION['user_logged_in']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error = '';

// Cek apakah sudah pernah daftar
$stmt = $pdo->prepare("SELECT id FROM calon_mahasiswa WHERE user_id = ?");
$stmt->execute([$user_id]);
if ($stmt->rowCount() > 0) {
    header("Location: dashboard_user.php");
    exit;
}

// Ambil daftar prodi
$stmt_prodi = $pdo->query("SELECT * FROM program_studi");
$prodi_list = $stmt_prodi->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $alamat = trim($_POST['alamat']);
    $tempat_lahir = trim($_POST['tempat_lahir']);
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $asal_sekolah = trim($_POST['asal_sekolah']);
    $prodi_id = $_POST['prodi_id'];
    $jalur_pendaftaran = 'Jalur Mandiri';

    // Ambil tahun dari tanggal lahir yang diinput
    $tahun_lahir = date('Y', strtotime($tanggal_lahir));

    if (empty($alamat) || empty($tempat_lahir) || empty($tanggal_lahir) || empty($asal_sekolah) || empty($prodi_id)) {
        $error = "Semua kolom formulir wajib diisi!";
    } elseif ($tahun_lahir > 2010) {
        $error = "Tahun lahir maksimal adalah 2010!";
    } else {
        // Generate nomor tes unik otomatis (contoh: USN-2027-0001)
        $stmt_count = $pdo->query("SELECT COUNT(*) as total FROM calon_mahasiswa");
        $row_count = $stmt_count->fetch();
        $next_number = $row_count['total'] + 1;
        $nomor_tes = "USN-2027-" . str_pad($next_number, 4, '0', STR_PAD_LEFT);

        $stmt_insert = $pdo->prepare("INSERT INTO calon_mahasiswa (user_id, alamat, tempat_lahir, tanggal_lahir, asal_sekolah, jalur_pendaftaran, prodi_id, nomor_tes, status_pendaftaran) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Menunggu Ujian')");
        if ($stmt_insert->execute([$user_id, $alamat, $tempat_lahir, $tanggal_lahir, $asal_sekolah, $jalur_pendaftaran, $prodi_id, $nomor_tes])) {
            header("Location: dashboard_user.php");
            exit;
        } else {
            $error = "Gagal menyimpan data pendaftaran.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Pendaftaran - PMB USN</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="auth-container" style="height: auto; padding: 40px 20px;">
        <div class="auth-card" style="max-width: 600px;">
            <h2>Formulir Pendaftaran Mahasiswa Baru</h2>
            <?php if ($error): ?>
                <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9rem;"><?= $error; ?></div>
            <?php endif; ?>

            <form action="" method="POST" onsubmit="return validateForm()">
                <div class="form-group">
                    <label>Jalur Pendaftaran</label>
                    <input type="text" value="Jalur Mandiri" disabled style="background: #e9ecef; font-weight: bold;">
                </div>
                <div class="form-group">
                    <label>Pilihan Program Studi</label>
                    <select name="prodi_id" required>
                        <option value="">-- Pilih Program Studi --</option>
                        <?php foreach ($prodi_list as $p): ?>
                            <option value="<?= $p['id']; ?>"><?= htmlspecialchars($p['nama_prodi']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Alamat Lengkap</label>
                    <textarea name="alamat" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir (Maksimal Tahun 2010)</label>
                    <!-- Batasi pilihan kalender maksimal tanggal 31 Desember 2010 -->
                    <input type="date" id="tanggal_lahir" name="tanggal_lahir" max="2010-12-31" required>
                </div>
                <div class="form-group">
                    <label>Asal Sekolah</label>
                    <input type="text" name="asal_sekolah" required>
                </div>
                <button type="submit" class="btn-block">Simpan Pendaftaran & Dapatkan Nomor Tes</button>
            </form>
            <div class="auth-links" style="margin-top: 15px;">
                <a href="dashboard_user.php">Kembali ke Dashboard</a>
            </div>
        </div>
    </div>

    <script>
        function validateForm() {
            const tglLahir = document.getElementById('tanggal_lahir').value;
            if (tglLahir) {
                const tahun = new Date(tglLahir).getFullYear();
                if (tahun > 2010) {
                    alert('Tahun lahir tidak boleh lebih dari tahun 2010!');
                    return false;
                }
            }
            return true;
        }
    </script>
</body>
</html>