<?php
session_start();
require_once 'database.php';

// Pengecekan sesi admin yang disesuaikan agar bisa multi-tab
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';
$action = $_GET['action'] ?? 'list';

// Hapus data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $stmt = $pdo->prepare("DELETE FROM calon_mahasiswa WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_calon_mahasiswa.php");
    exit;
}

// Proses Tambah / Edit Data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? '';
    $user_id = $_POST['user_id'];
    $prodi_id = $_POST['prodi_id'];
    $nomor_tes = trim($_POST['nomor_tes']);
    $asal_sekolah = trim($_POST['asal_sekolah']);
    $status_pendaftaran = $_POST['status_pendaftaran'];

    if (empty($user_id) || empty($prodi_id) || empty($nomor_tes) || empty($asal_sekolah)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        if ($id) {
            // Update data
            $stmt = $pdo->prepare("UPDATE calon_mahasiswa SET user_id = ?, prodi_id = ?, nomor_tes = ?, asal_sekolah = ?, status_pendaftaran = ? WHERE id = ?");
            $stmt->execute([$user_id, $prodi_id, $nomor_tes, $asal_sekolah, $status_pendaftaran, $id]);
            $success = "Data calon mahasiswa berhasil diperbarui!";
        } else {
            // Tambah data baru
            // Cek apakah user_id sudah punya data pendaftaran
            $cek = $pdo->prepare("SELECT id FROM calon_mahasiswa WHERE user_id = ?");
            $cek->execute([$user_id]);
            if ($cek->rowCount() > 0) {
                $error = "User ini sudah memiliki data pendaftaran calon mahasiswa!";
            } else {
                $stmt = $pdo->prepare("INSERT INTO calon_mahasiswa (user_id, prodi_id, nomor_tes, asal_sekolah, status_pendaftaran) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $prodi_id, $nomor_tes, $asal_sekolah, $status_pendaftaran]);
                $success = "Calon mahasiswa baru berhasil ditambahkan!";
            }
        }
        if (!$error) {
            header("Refresh: 1; URL=admin_calon_mahasiswa.php");
        }
    }
}

// Ambil data untuk form edit
$edit_data = null;
if ($action == 'edit' && isset($_GET['id'])) {
    $stmt_edit = $pdo->prepare("SELECT * FROM calon_mahasiswa WHERE id = ?");
    $stmt_edit->execute([$_GET['id']]);
    $edit_data = $stmt_edit->fetch();
}

// Ambil list users (role user) dan program studi untuk dropdown form
$users_list = $pdo->query("SELECT * FROM users WHERE role = 'user' ORDER BY nama_lengkap ASC")->fetchAll();
$prodi_list = $pdo->query("SELECT * FROM program_studi ORDER BY nama_prodi ASC")->fetchAll();

// Pencarian dan list data
$search = $_GET['search'] ?? '';
$query = "SELECT cm.*, u.nama_lengkap, u.email, u.no_hp, ps.nama_prodi FROM calon_mahasiswa cm JOIN users u ON cm.user_id = u.id JOIN program_studi ps ON cm.prodi_id = ps.id";
if ($search) {
    $query .= " WHERE u.nama_lengkap LIKE ? OR cm.nomor_tes LIKE ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query($query);
}
$list_mhs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Calon Mahasiswa - Admin PMB USN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; background: #f4f6f9; }
        .sidebar { width: 260px; background: var(--primary-color); height: 100vh; position: fixed; padding: 20px 0; color: #fff; }
        .sidebar h2 { text-align: center; font-size: 1.2rem; margin-bottom: 30px; color: var(--gold-color); }
        .sidebar a { display: block; color: #adb5bd; padding: 12px 25px; text-decoration: none; font-weight: 500; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: var(--secondary-color); color: #fff; border-left: 4px solid var(--gold-color); }
        .main-content { margin-left: 260px; padding: 40px; width: calc(100% - 260px); }
        table { width: 100%; background: #fff; border-collapse: collapse; margin-top: 20px; border-radius: 6px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #dee2e6; font-size: 0.9rem; }
        th { background: var(--primary-color); color: #fff; }
        .form-card { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); max-width: 600px; margin-top: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ced4da; border-radius: 5px; font-size: 0.9rem; }
        .btn-success { background: #28a745; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-secondary { background: #6c757d; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin PMB USN</h2>
        <a href="dashboard_admin.php">Dashboard</a>
        <a href="admin_calon_mahasiswa.php" class="active">Data Calon Mahasiswa</a>
        <a href="admin_soal.php">Data Soal Tes</a>
        <a href="admin_kelulusan.php">Peserta Lulus & Tidak Lulus</a>
        <a href="admin_daftar_ulang.php">Daftar Ulang & NIM</a>
        <a href="logout.php" style="color: #ff6b6b; margin-top: 30px;">Logout</a>
    </div>

    <div class="main-content">
        <h2>Kelola Data Calon Mahasiswa</h2>

        <?php if ($error): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-top: 15px;"><?= $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div style="background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-top: 15px;"><?= $success; ?></div>
        <?php endif; ?>

        <?php if ($action == 'tambah' || $action == 'edit'): ?>
            <!-- Form Tambah / Edit -->
            <div class="form-card">
                <h3><?= $action == 'edit' ? 'Edit Data Calon Mahasiswa' : 'Tambah Calon Mahasiswa Baru'; ?></h3>
                <form method="POST" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="<?= $edit_data['id'] ?? ''; ?>">
                    
                    <div class="form-group">
                        <label>Pilih Akun User</label>
                        <select name="user_id" required>
                            <option value="">-- Pilih Akun --</option>
                            <?php foreach ($users_list as $u): ?>
                                <option value="<?= $u['id']; ?>" <?= (isset($edit_data) && $edit_data['user_id'] == $u['id']) ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($u['nama_lengkap'] . ' (' . $u['email'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Program Studi Pilihan</label>
                        <select name="prodi_id" required>
                            <option value="">-- Pilih Program Studi --</option>
                            <?php foreach ($prodi_list as $p): ?>
                                <option value="<?= $p['id']; ?>" <?= (isset($edit_data) && $edit_data['prodi_id'] == $p['id']) ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($p['nama_prodi']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Nomor Tes</label>
                        <input type="text" name="nomor_tes" value="<?= htmlspecialchars($edit_data['nomor_tes'] ?? ''); ?>" required placeholder="Contoh: TES2027001">
                    </div>

                    <div class="form-group">
                        <label>Asal Sekolah</label>
                        <input type="text" name="asal_sekolah" value="<?= htmlspecialchars($edit_data['asal_sekolah'] ?? ''); ?>" required placeholder="Contoh: SMA Negeri 1 Jakarta">
                    </div>

                    <div class="form-group">
                        <label>Status Pendaftaran / Ujian</label>
                        <select name="status_pendaftaran" required>
                            <option value="Menunggu Ujian" <?= (isset($edit_data) && $edit_data['status_pendaftaran'] == 'Menunggu Ujian') ? 'selected' : ''; ?>>Menunggu Ujian</option>
                            <option value="Selesai Ujian" <?= (isset($edit_data) && $edit_data['status_pendaftaran'] == 'Selesai Ujian') ? 'selected' : ''; ?>>Selesai Ujian</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-success">Simpan Data</button>
                    <a href="admin_calon_mahasiswa.php" class="btn-secondary">Batal</a>
                </form>
            </div>

        <?php else: ?>
            <!-- Tabel Data & Tombol Tambah -->
            <div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
                <form method="GET" style="display: flex; gap: 10px;">
                    <input type="text" name="search" placeholder="Cari nama atau nomor tes..." value="<?= htmlspecialchars($search); ?>" style="padding: 10px; width: 300px; border: 1px solid #ced4da; border-radius: 5px;">
                    <button type="submit" class="btn-primary" style="padding: 10px 20px;">Cari</button>
                </form>
                <a href="admin_calon_mahasiswa.php?action=tambah" class="btn-success">+ Tambah Calon Mahasiswa</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>No Tes</th>
                        <th>Nama Lengkap</th>
                        <th>Prodi</th>
                        <th>Asal Sekolah</th>
                        <th>Status Ujian</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($list_mhs)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #777;">Belum ada data calon mahasiswa.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($list_mhs as $m): ?>
                        <tr>
                            <td><?= htmlspecialchars($m['nomor_tes']); ?></td>
                            <td><?= htmlspecialchars($m['nama_lengkap']); ?></td>
                            <td><?= htmlspecialchars($m['nama_prodi']); ?></td>
                            <td><?= htmlspecialchars($m['asal_sekolah']); ?></td>
                            <td><?= htmlspecialchars($m['status_pendaftaran']); ?></td>
                            <td>
                                <a href="admin_calon_mahasiswa.php?action=edit&id=<?= $m['id']; ?>" style="color: #007bff; text-decoration: none; font-weight: bold; margin-right: 10px;">Edit</a>
                                <a href="admin_calon_mahasiswa.php?hapus=<?= $m['id']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?')" style="color: #dc3545; text-decoration: none; font-weight: bold;">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>