-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 08, 2026 at 02:17 PM
-- Server version: 8.4.3
-- PHP Version: 8.3.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `usn_pmb`
--

-- --------------------------------------------------------

--
-- Table structure for table `calon_mahasiswa`
--

CREATE TABLE `calon_mahasiswa` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `tempat_lahir` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `asal_sekolah` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jalur_pendaftaran` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Jalur Mandiri',
  `prodi_id` int NOT NULL,
  `nomor_tes` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_pendaftaran` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status_pendaftaran` enum('Menunggu Ujian','Selesai Ujian') COLLATE utf8mb4_unicode_ci DEFAULT 'Menunggu Ujian'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `calon_mahasiswa`
--

INSERT INTO `calon_mahasiswa` (`id`, `user_id`, `alamat`, `tempat_lahir`, `tanggal_lahir`, `asal_sekolah`, `jalur_pendaftaran`, `prodi_id`, `nomor_tes`, `tanggal_pendaftaran`, `status_pendaftaran`) VALUES
(1, 1, 'Jl.kota mangga kota depok', 'Tiongkok', '2005-10-14', 'SMK Manay', 'Jalur Mandiri', 1, 'USN-2027-0001', '2026-10-29 15:48:29', 'Selesai Ujian'),
(2, 3, '123', '123', '2026-11-05', '123', 'Jalur Mandiri', 1, 'USN-2027-0002', '2026-11-05 00:26:37', 'Selesai Ujian'),
(3, 4, 'jl mam', 'Tiongkok', '2026-11-05', 'smk', 'Jalur Mandiri', 2, 'USN-2027-0003', '2026-11-05 00:58:42', 'Selesai Ujian'),
(4, 5, 'jln ibulahir', 'Bandung', '2009-06-17', 'sman  jakarta', 'Jalur Mandiri', 3, 'USN-2027-0004', '2026-11-05 12:03:14', 'Selesai Ujian');

-- --------------------------------------------------------

--
-- Table structure for table `daftar_ulang`
--

CREATE TABLE `daftar_ulang` (
  `id` int NOT NULL,
  `calon_mahasiswa_id` int NOT NULL,
  `status_daftar_ulang` enum('Belum Daftar Ulang','Selesai') COLLATE utf8mb4_unicode_ci DEFAULT 'Belum Daftar Ulang',
  `tanggal_daftar_ulang` timestamp NULL DEFAULT NULL,
  `nim` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_wali` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_wali` text COLLATE utf8mb4_unicode_ci,
  `ukuran_almamater` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nomor_kip_kks` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `daftar_ulang`
--

INSERT INTO `daftar_ulang` (`id`, `calon_mahasiswa_id`, `status_daftar_ulang`, `tanggal_daftar_ulang`, `nim`, `no_wali`, `alamat_wali`, `ukuran_almamater`, `nomor_kip_kks`) VALUES
(1, 1, 'Selesai', '2026-10-29 15:57:06', 'USN27-001', NULL, NULL, NULL, NULL),
(2, 2, 'Selesai', '2026-11-05 00:28:30', 'USN27-002', NULL, NULL, NULL, NULL),
(3, 3, 'Selesai', '2026-11-05 01:02:05', 'USN27-003', NULL, NULL, NULL, NULL),
(4, 4, 'Selesai', '2026-11-05 12:15:33', 'USN27-004', '888', 'oman', 'M', '');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_tes`
--

CREATE TABLE `hasil_tes` (
  `id` int NOT NULL,
  `calon_mahasiswa_id` int NOT NULL,
  `nilai` int DEFAULT '0',
  `status_kelulusan` enum('Menunggu','Lulus','Tidak Lulus') COLLATE utf8mb4_unicode_ci DEFAULT 'Menunggu',
  `tanggal_ujian` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `hasil_tes`
--

INSERT INTO `hasil_tes` (`id`, `calon_mahasiswa_id`, `nilai`, `status_kelulusan`, `tanggal_ujian`) VALUES
(1, 1, 100, 'Lulus', '2026-10-29 15:49:56'),
(2, 2, 100, 'Lulus', '2026-11-05 00:27:23'),
(3, 3, 100, 'Lulus', '2026-11-05 00:59:32'),
(4, 4, 100, 'Lulus', '2026-11-05 12:05:26');

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan`
--

CREATE TABLE `pengaturan` (
  `id` int NOT NULL,
  `nama_pengaturan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nilai_pengaturan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengaturan`
--

INSERT INTO `pengaturan` (`id`, `nama_pengaturan`, `nilai_pengaturan`) VALUES
(1, 'batas_kelulusan', '60');

-- --------------------------------------------------------

--
-- Table structure for table `program_studi`
--

CREATE TABLE `program_studi` (
  `id` int NOT NULL,
  `nama_prodi` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `program_studi`
--

INSERT INTO `program_studi` (`id`, `nama_prodi`, `deskripsi`, `gambar`) VALUES
(1, 'Teknik Komputer', 'Program studi yang mempelajari komputer, pemrograman, jaringan, perangkat keras, dan teknologi informasi.', 'teknik_komputer.jpg'),
(2, 'Ilmu Hukum', 'Program studi yang mempelajari hukum, peraturan, keadilan, dan sistem hukum di Indonesia.', 'ilmu_hukum.jpg'),
(3, 'Kedokteran', 'Program studi yang mempelajari ilmu medis, kesehatan manusia, dan dasar-dasar pelayanan kesehatan.', 'kedokteran.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `soal_tes`
--

CREATE TABLE `soal_tes` (
  `id` int NOT NULL,
  `prodi_id` int NOT NULL,
  `pertanyaan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pilihan_a` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pilihan_b` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pilihan_c` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pilihan_d` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jawaban_benar` enum('A','B','C','D') COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `soal_tes`
--

INSERT INTO `soal_tes` (`id`, `prodi_id`, `pertanyaan`, `pilihan_a`, `pilihan_b`, `pilihan_c`, `pilihan_d`, `jawaban_benar`) VALUES
(1, 1, 'Apa fungsi utama CPU pada komputer?', 'Menyimpan file secara permanen', 'Memproses instruksi dan data', 'Menampilkan gambar', 'Mencetak dokumen', 'B'),
(2, 1, 'Manakah yang termasuk perangkat input?', 'Monitor', 'Printer', 'Keyboard', 'Speaker', 'C'),
(3, 1, 'Apa kepanjangan dari RAM?', 'Random Access Memory', 'Read Access Machine', 'Rapid Active Memory', 'Remote Access Module', 'A'),
(4, 1, 'Bahasa yang umum digunakan untuk membuat struktur halaman web adalah ...', 'HTML', 'SQL', 'Photoshop', 'Excel', 'A'),
(5, 1, 'Apa fungsi utama jaringan komputer?', 'Menghubungkan perangkat agar dapat bertukar data', 'Memperbesar ukuran layar', 'Mengganti sistem operasi secara otomatis', 'Menghapus semua file', 'A'),
(6, 2, 'Apa dasar hukum tertinggi di Indonesia?', 'Peraturan daerah', 'Undang-undang biasa', 'UUD Negara Republik Indonesia Tahun 1945', 'Peraturan sekolah', 'C'),
(7, 2, 'Apa tujuan utama hukum dalam masyarakat?', 'Menciptakan ketertiban dan keadilan', 'Membatasi seluruh kegiatan masyarakat', 'Menguntungkan satu kelompok saja', 'Menghapus seluruh perbedaan pendapat', 'A'),
(8, 2, 'Lembaga yang bertugas mengadili perkara di pengadilan adalah ...', 'Pengadilan', 'Perpustakaan', 'Museum', 'Kantor pos', 'A'),
(9, 2, 'Apa yang dimaksud dengan hak?', 'Sesuatu yang wajib dihukum', 'Sesuatu yang patut diterima atau dimiliki seseorang', 'Larangan untuk semua orang', 'Hukuman bagi pelanggar', 'B'),
(10, 2, 'Mengapa setiap warga negara harus menaati hukum?', 'Agar dapat menghindari seluruh kewajiban', 'Agar tercipta ketertiban dan kepastian hukum', 'Agar tidak perlu menghormati orang lain', 'Agar hanya pemerintah yang memiliki hak', 'B'),
(11, 3, 'Organ tubuh manusia yang berfungsi memompa darah adalah ...', 'Paru-paru', 'Hati', 'Jantung', 'Lambung', 'C'),
(12, 3, 'Organ yang berfungsi utama untuk pertukaran oksigen dan karbon dioksida adalah ...', 'Paru-paru', 'Ginjal', 'Usus', 'Pankreas', 'A'),
(13, 3, 'Apa fungsi utama sel darah merah?', 'Membantu mengangkut oksigen', 'Mencerna makanan', 'Menghasilkan urine', 'Mengatur gerakan tulang', 'A'),
(14, 3, 'Mengapa mencuci tangan penting untuk kesehatan?', 'Agar tubuh tidak membutuhkan air', 'Untuk membantu mengurangi penyebaran kuman', 'Agar tubuh tidak membutuhkan istirahat', 'Untuk menggantikan semua obat', 'B'),
(15, 3, 'Zat gizi yang menjadi sumber energi utama bagi tubuh adalah ...', 'Karbohidrat', 'Mineral saja', 'Air saja', 'Vitamin saja', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `nama_lengkap` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_hp` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama_lengkap`, `email`, `password`, `no_hp`, `role`, `created_at`) VALUES
(1, 'james', 'james1@gmail.com', '$2y$10$0b3eKP/Oz3xQbgyD4iT/n.PeB9ROUZ8lyQFksId1BTKx/yr3ZmLOS', '089140', 'user', '2026-10-29 15:42:09'),
(2, 'sky', 'admin@usn.ac.id', '$2y$10$NvVdTEhsdYmt7RLuZ2G4fOuOhU742xhVMDASFp6vly7wNnKeav0ry', '085891', 'admin', '2026-10-29 16:02:07'),
(3, 'bagas', 'bagas@1', '$2y$10$fmjX166H.c4lHrzzyoDIE.XYb1XyTOjyLpnYBPceLa4QpWfCDDyyq', '123', 'user', '2026-11-05 00:25:42'),
(4, 'dafa', 'daf@2', '$2y$10$nn.Kmpt1EsPTOwdt.jyDxulUJaIJ31Sfn7KHmuV17SS61FMrOtONi', '123', 'user', '2026-11-05 00:52:23'),
(5, 'pillow', 'pillow@1', '$2y$10$BAdOncSoFJ11uYoSlJ59PODv/Jw2tNh.voGu4dEBVIR5SLn9I8hia', '111', 'user', '2026-11-05 11:59:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calon_mahasiswa`
--
ALTER TABLE `calon_mahasiswa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nomor_tes` (`nomor_tes`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `prodi_id` (`prodi_id`);

--
-- Indexes for table `daftar_ulang`
--
ALTER TABLE `daftar_ulang`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nim` (`nim`),
  ADD KEY `calon_mahasiswa_id` (`calon_mahasiswa_id`);

--
-- Indexes for table `hasil_tes`
--
ALTER TABLE `hasil_tes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `calon_mahasiswa_id` (`calon_mahasiswa_id`);

--
-- Indexes for table `pengaturan`
--
ALTER TABLE `pengaturan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program_studi`
--
ALTER TABLE `program_studi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `soal_tes`
--
ALTER TABLE `soal_tes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prodi_id` (`prodi_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `calon_mahasiswa`
--
ALTER TABLE `calon_mahasiswa`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `daftar_ulang`
--
ALTER TABLE `daftar_ulang`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hasil_tes`
--
ALTER TABLE `hasil_tes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pengaturan`
--
ALTER TABLE `pengaturan`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `program_studi`
--
ALTER TABLE `program_studi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `soal_tes`
--
ALTER TABLE `soal_tes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `calon_mahasiswa`
--
ALTER TABLE `calon_mahasiswa`
  ADD CONSTRAINT `calon_mahasiswa_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `calon_mahasiswa_ibfk_2` FOREIGN KEY (`prodi_id`) REFERENCES `program_studi` (`id`);

--
-- Constraints for table `daftar_ulang`
--
ALTER TABLE `daftar_ulang`
  ADD CONSTRAINT `daftar_ulang_ibfk_1` FOREIGN KEY (`calon_mahasiswa_id`) REFERENCES `calon_mahasiswa` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `hasil_tes`
--
ALTER TABLE `hasil_tes`
  ADD CONSTRAINT `hasil_tes_ibfk_1` FOREIGN KEY (`calon_mahasiswa_id`) REFERENCES `calon_mahasiswa` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `soal_tes`
--
ALTER TABLE `soal_tes`
  ADD CONSTRAINT `soal_tes_ibfk_1` FOREIGN KEY (`prodi_id`) REFERENCES `program_studi` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
