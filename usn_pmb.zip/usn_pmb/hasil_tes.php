<?php
session_start();
require_once 'database.php';

// Menyesuaikan dengan pemeriksaan sesi multi-tab user
if (!isset($_SESSION['user_logged_in']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data pendaftaran dan hasil tes (tanpa perlu menampilkan nilai ke layar user)
$stmt = $pdo->prepare("SELECT cm.*, ps.nama_prodi, ht.status_kelulusan, ht.tanggal_ujian FROM calon_mahasiswa cm JOIN program_studi ps ON cm.prodi_id = ps.id LEFT JOIN hasil_tes ht ON cm.id = ht.calon_mahasiswa_id WHERE cm.user_id = ?");
$stmt->execute([$user_id]);
$data = $stmt->fetch();

if (!$data || $data['status_pendaftaran'] != 'Selesai Ujian') {
    header("Location: dashboard_user.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Tes - PMB USN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: #f4f7f6;
            color: #333;
        }
        .container {
            max-width: 650px;
            margin: 110px auto 40px auto;
            padding: 0 20px;
        }
        .card {
            background: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(13, 27, 42, 0.08);
            border-top: 5px solid #0077b6;
            text-align: center;
        }
        .card h2 {
            color: #0d1b2a;
            font-size: 1.6rem;
            margin-bottom: 5px;
        }
        .status-box {
            background: #f8fafc;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            margin: 25px 0;
        }
        .status-badge {
            font-size: 1.2rem;
            font-weight: 700;
            display: inline-block;
            padding: 8px 20px;
            border-radius: 20px;
            margin-top: 10px;
        }
        .status-lulus {
            background: #dcfce7;
            color: #166534;
        }
        .status-tidak {
            background: #fee2e2;
            color: #991b1b;
        }
        .info-detail {
            border-top: 1px solid #e2e8f0;
            padding-top: 20px;
            text-align: left;
            margin-bottom: 25px;
        }
        .info-detail p {
            margin-bottom: 8px;
            font-size: 0.95rem;
            color: #475569;
        }
        .info-detail p strong {
            color: #0d1b2a;
        }
        .btn-action {
            display: block;
            width: 100%;
            padding: 14px;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        .btn-action:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

    <!-- Navbar Modern & Bersih -->
    <nav class="navbar" style="background: #0d1b2a; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <div class="logo-container">
            <span class="logo-badge" style="background: #d4af37; color: #0d1b2a; padding: 6px 10px; border-radius: 6px; font-weight: bold;">USN</span>
            <h1 style="font-size: 1.1rem; color: #fff;">PMB USN — Hasil Tes</h1>
        </div>
        <ul class="nav-links">
            <li><a href="dashboard_user.php">Dashboard</a></li>
            <li><a href="logout.php" style="color: #f87171; font-weight: 600;">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <h2>Hasil Ujian Seleksi Mandiri</h2>
            <p style="color: #64748b; margin-bottom: 10px;">Nomor Tes: <b><?= htmlspecialchars($data['nomor_tes']); ?></b></p>

            <div class="status-box">
                <p style="color: #64748b; font-size: 0.95rem; margin-bottom: 5px;">Ujian online telah selesai dievaluasi oleh sistem.</p>
                <div>
                    <?php if ($data['status_kelulusan'] == 'Lulus'): ?>
                        <span class="status-badge status-lulus">🎉 Status: LULUS</span>
                    <?php else: ?>
                        <span class="status-badge status-tidak">❌ Status: TIDAK LULUS</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="info-detail">
                <p><strong>Nama Lengkap:</strong> <?= htmlspecialchars($_SESSION['nama_lengkap']); ?></p>
                <p><strong>Program Studi:</strong> <?= htmlspecialchars($data['nama_prodi']); ?></p>
                <p><strong>Waktu Selesai Ujian:</strong> <?= htmlspecialchars($data['tanggal_ujian']); ?></p>
            </div>

            <?php if ($data['status_kelulusan'] == 'Lulus'): ?>
                <a href="daftar_ulang.php" class="btn-action" style="background: #10b981; color: #fff; margin-bottom: 15px;">Lanjut ke Proses Daftar Ulang</a>
            <?php else: ?>
                <p style="color: #991b1b; font-size: 0.95rem; margin-bottom: 20px; font-weight: 500;">Mohon maaf, berdasarkan hasil seleksi ujian mandiri, Anda dinyatakan belum memenuhi batas minimum kelulusan.</p>
            <?php endif; ?>

            <div>
                <a href="dashboard_user.php" style="color: #0077b6; text-decoration: none; font-weight: 600;">← Kembali ke Dashboard</a>
            </div>
        </div>
    </div>

</body>
</html>