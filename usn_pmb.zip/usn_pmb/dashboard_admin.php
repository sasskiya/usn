<?php
session_start();
require_once 'database.php';

// PERBAIKAN: Menyesuaikan dengan variabel sesi baru khusus admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Statistik
$total_pendaftar = $pdo->query("SELECT COUNT(*) FROM calon_mahasiswa")->fetchColumn();
$total_lulus = $pdo->query("SELECT COUNT(*) FROM hasil_tes WHERE status_kelulusan = 'Lulus'")->fetchColumn();
$total_tidak_lulus = $pdo->query("SELECT COUNT(*) FROM hasil_tes WHERE status_kelulusan = 'Tidak Lulus'")->fetchColumn();
$total_daftar_ulang = $pdo->query("SELECT COUNT(*) FROM daftar_ulang WHERE status_daftar_ulang = 'Selesai'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - PMB USN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; background: #f4f6f9; }
        .sidebar { width: 260px; background: var(--primary-color); height: 100vh; position: fixed; padding: 20px 0; color: #fff; }
        .sidebar h2 { text-align: center; font-size: 1.2rem; margin-bottom: 30px; color: var(--gold-color); }
        .sidebar a { display: block; color: #adb5bd; padding: 12px 25px; text-decoration: none; font-weight: 500; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: var(--secondary-color); color: #fff; border-left: 4px solid var(--gold-color); }
        .main-content { margin-left: 260px; padding: 40px; width: calc(100% - 260px); }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); border-top: 4px solid var(--accent-color); }
        .stat-card h3 { font-size: 0.9rem; color: #666; margin-bottom: 8px; }
        .stat-card p { font-size: 1.8rem; font-weight: bold; color: var(--primary-color); }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Admin PMB USN</h2>
        <a href="dashboard_admin.php" class="active">Dashboard</a>
        <a href="admin_calon_mahasiswa.php">Data Calon Mahasiswa</a>
        <a href="admin_soal.php">Data Soal Tes</a>
        <a href="admin_kelulusan.php">Peserta Lulus & Tidak Lulus</a>
        <a href="admin_daftar_ulang.php">Daftar Ulang & NIM</a>
        <a href="logout.php" style="color: #ff6b6b; margin-top: 30px;">Logout</a>
    </div>

    <div class="main-content">
        <h2>Dashboard Administrator</h2>
        <p style="color: #666; margin-bottom: 25px;">Selamat datang kembali, Administrator USN.</p>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Pendaftar</h3>
                <p><?= $total_pendaftar; ?></p>
            </div>
            <div class="stat-card" style="border-top-color: #28a745;">
                <h3>Peserta Lulus</h3>
                <p><?= $total_lulus; ?></p>
            </div>
            <div class="stat-card" style="border-top-color: #dc3545;">
                <h3>Peserta Tidak Lulus</h3>
                <p><?= $total_tidak_lulus; ?></p>
            </div>
            <div class="stat-card" style="border-top-color: var(--gold-color);">
                <h3>Selesai Daftar Ulang</h3>
                <p><?= $total_daftar_ulang; ?></p>
            </div>
        </div>
    </div>

</body>
</html>