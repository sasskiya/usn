<?php
require_once 'database.php';

$email_admin = 'admin@usn.ac.id';
$password_plain = 'AdminUSN2027!';
$password_hash = password_hash($password_plain, PASSWORD_DEFAULT);
$nama = 'Administrator USN';
$no_hp = '081234567890';

// Cek apakah admin sudah ada
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email_admin]);
if ($stmt->rowCount() == 0) {
    $stmt = $pdo->prepare("INSERT INTO users (nama_lengkap, email, password, no_hp, role) VALUES (?, ?, ?, ?, 'admin')");
    $stmt->execute([$nama, $email_admin, $password_hash, $no_hp]);
    echo "<h3>Akun admin berhasil dibuat!</h3>";
    echo "<p>Email: <b>$email_admin</b></p>";
    echo "<p>Password: <b>$password_plain</b></p>";
    echo "<p><a href='login.php'>Login ke halaman Admin sekarang</a></p>";
} else {
    echo "<h3>Akun admin sudah ada di dalam database.</h3>";
    echo "<p><a href='login.php'>Silakan Login di sini</a></p>";
}
?>